export enum Levels {
  Regions = 'Regions',
  Countries = 'Countries',
  States = 'States', // regions, provinces
  Cities = 'Cities'
}